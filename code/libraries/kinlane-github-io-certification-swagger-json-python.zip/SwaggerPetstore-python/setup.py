import sys
from setuptools import setup, find_packages



# To install the library, open a Terminal shell, then run this
# file by typing:
#
# python setup.py install
#
# You need to have the setuptools module installed.
# Try reading the setuptools documentation:
# http://pypi.python.org/pypi/setuptools

REQUIRES = []

setup(
    name="SwaggerPetstore",
    version="v2",
    description="Certification",
    author_email="",
    url="",
    keywords=["Swagger", "Certification"],
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    long_description="""\
    This is an certification for all my certification entries. I use a single certification system to manage all my sites. Based upon tagging, I then publish each post out to its respective Github Page based repo.
    """
)


