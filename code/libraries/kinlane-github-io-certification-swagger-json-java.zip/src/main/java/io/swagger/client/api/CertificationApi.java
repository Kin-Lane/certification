package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Certification;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class CertificationApi {
  String basePath = "https://certification.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * all certifications
   * all certifications
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @param query a text query to search across certification
   * @return List<Certification>
   */
  public List<Certification> getCertifications (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add a certification post
   * add a certification post
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @param postDate date the certification was posted
   * @param title ttle for the certification
   * @param author author of the certification
   * @param summary summary for the certification
   * @param body full text for the certification
   * @param footer curated id the certification originated from
   * @param status status of the certification
   * @param curatedId full text for the certification
   * @return List<Certification>
   */
  public List<Certification> addCertification (String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * published certifications
   * published certifications
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @return List<Certification>
   */
  public List<Certification> getPublishedCertifications (String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/published/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * Retrieve a certification using its slug
   * Returns the certification detail
   * @param certificationId the unique id for certification entry
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @return List<Certification>
   */
  public List<Certification> getCertification (String certificationId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * update certification
   * update certification
   * @param certificationId the unique id for certification entry
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @param postDate date the certification was posted
   * @param title ttle for the certification
   * @param author author of the certification
   * @param summary summary for the certification
   * @param body full text for the certification
   * @param footer curated id the certification originated from
   * @param status status of the certification
   * @param curatedId full text for the certification
   * @return List<Certification>
   */
  public List<Certification> updateCertification (String certificationId, String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete certification
   * delete certification
   * @param certificationId the unique id for certification entry
   * @param appid your appid for accessing the certification
   * @param appkey your appkey for accessing the certification
   * @return List<Certification>
   */
  public List<Certification> deleteCertification (String certificationId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
