package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Certification  {
  
  private String postDate = null;
  private String title = null;
  private String author = null;
  private String summary = null;
  private String body = null;
  private String footer = null;
  private String status = null;

  
  /**
   * date the certification was posted
   **/
  @ApiModelProperty(value = "date the certification was posted")
  @JsonProperty("post_date")
  public String getPostDate() {
    return postDate;
  }
  public void setPostDate(String postDate) {
    this.postDate = postDate;
  }

  
  /**
   * title for the certification
   **/
  @ApiModelProperty(value = "title for the certification")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  
  /**
   * author of the certification
   **/
  @ApiModelProperty(value = "author of the certification")
  @JsonProperty("author")
  public String getAuthor() {
    return author;
  }
  public void setAuthor(String author) {
    this.author = author;
  }

  
  /**
   * summary for the certification
   **/
  @ApiModelProperty(value = "summary for the certification")
  @JsonProperty("summary")
  public String getSummary() {
    return summary;
  }
  public void setSummary(String summary) {
    this.summary = summary;
  }

  
  /**
   * full body text of the certification
   **/
  @ApiModelProperty(value = "full body text of the certification")
  @JsonProperty("body")
  public String getBody() {
    return body;
  }
  public void setBody(String body) {
    this.body = body;
  }

  
  /**
   * footer text for the certification
   **/
  @ApiModelProperty(value = "footer text for the certification")
  @JsonProperty("footer")
  public String getFooter() {
    return footer;
  }
  public void setFooter(String footer) {
    this.footer = footer;
  }

  
  /**
   * status of the certification
   **/
  @ApiModelProperty(value = "status of the certification")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Certification {\n");
    
    sb.append("  postDate: ").append(postDate).append("\n");
    sb.append("  title: ").append(title).append("\n");
    sb.append("  author: ").append(author).append("\n");
    sb.append("  summary: ").append(summary).append("\n");
    sb.append("  body: ").append(body).append("\n");
    sb.append("  footer: ").append(footer).append("\n");
    sb.append("  status: ").append(status).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
