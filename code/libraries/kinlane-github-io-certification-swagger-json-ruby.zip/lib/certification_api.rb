require "uri"

class CertificationApi
  basePath = "https://certification.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # all certifications
  # all certifications
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param [Hash] opts the optional parameters
  # @option opts [string] :query a text query to search across certification
  # @return array[certification]
  def self.get_certifications(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/certification/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = opts[:'query'] if opts[:'query']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # add a certification post
  # add a certification post
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param post_date date the certification was posted
  # @param title ttle for the certification
  # @param author author of the certification
  # @param summary summary for the certification
  # @param body full text for the certification
  # @param footer curated id the certification originated from
  # @param status status of the certification
  # @param curated_id full text for the certification
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.add_certification(appid, appkey, post_date, title, author, summary, body, footer, status, curated_id, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "post_date is required" if post_date.nil?
    raise "title is required" if title.nil?
    raise "author is required" if author.nil?
    raise "summary is required" if summary.nil?
    raise "body is required" if body.nil?
    raise "footer is required" if footer.nil?
    raise "status is required" if status.nil?
    raise "curated_id is required" if curated_id.nil?

    # resource path
    path = "/certification/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'post_date'] = post_date
    query_params[:'title'] = title
    query_params[:'author'] = author
    query_params[:'summary'] = summary
    query_params[:'body'] = body
    query_params[:'footer'] = footer
    query_params[:'status'] = status
    query_params[:'curated_id'] = curated_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # published certifications
  # published certifications
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.get_published_certifications(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/certification/published/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # Retrieve a certification using its slug
  # Returns the certification detail
  # @param certification_id the unique id for certification entry
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.get_certification(certification_id, appid, appkey, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/certification/{certification_id}/".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # update certification
  # update certification
  # @param certification_id the unique id for certification entry
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param post_date date the certification was posted
  # @param title ttle for the certification
  # @param author author of the certification
  # @param summary summary for the certification
  # @param body full text for the certification
  # @param footer curated id the certification originated from
  # @param status status of the certification
  # @param curated_id full text for the certification
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.update_certification(certification_id, appid, appkey, post_date, title, author, summary, body, footer, status, curated_id, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "post_date is required" if post_date.nil?
    raise "title is required" if title.nil?
    raise "author is required" if author.nil?
    raise "summary is required" if summary.nil?
    raise "body is required" if body.nil?
    raise "footer is required" if footer.nil?
    raise "status is required" if status.nil?
    raise "curated_id is required" if curated_id.nil?

    # resource path
    path = "/certification/{certification_id}/".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'post_date'] = post_date
    query_params[:'title'] = title
    query_params[:'author'] = author
    query_params[:'summary'] = summary
    query_params[:'body'] = body
    query_params[:'footer'] = footer
    query_params[:'status'] = status
    query_params[:'curated_id'] = curated_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # delete certification
  # delete certification
  # @param certification_id the unique id for certification entry
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.delete_certification(certification_id, appid, appkey, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/certification/{certification_id}/".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end
end
