require "uri"

class TagsApi
  basePath = "https://certification.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # certification tags by week certifications
  # certification tags by week certifications
  # @param tag the tag to filter by
  # @param week the week to filter by, defaults to this week
  # @param [Hash] opts the optional parameters
  # @return array[certification]
  def self.get_certification_tag_c_certification(tag, week, opts = {})
    # verify existence of params
    raise "tag is required" if tag.nil?
    raise "week is required" if week.nil?

    # resource path
    path = "/certification/tags/{tag}/certification/".sub('{format}','json').sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'week'] = week

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| certification.new(response) }
  end

  # certification tags
  # certification tags
  # @param certification_id id for certification
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.getcertification_tags(certification_id, appid, appkey, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/certification/{certification_id}/tags/".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # add tag to certification
  # add tag to certification
  # @param certification_id id for the certification
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param tag tag name
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.add_certification_tag(certification_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/certification/{certification_id}/tags/".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'tag'] = tag

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # delete certification tag
  # delete certification tag
  # @param certification_id id for the certification
  # @param appid your appid for accessing the certification
  # @param appkey your appkey for accessing the certification
  # @param tag tag to remove from certification
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.deletecertification_tag(certification_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "certification_id is required" if certification_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/certification/{certification_id}/tags/{tag}".sub('{format}','json').sub('{' + 'certification_id' + '}', certification_id.to_s).sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end
end
