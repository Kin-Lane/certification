#import "SWGCertification.h"

@implementation SWGCertification
  
+ (JSONKeyMapper *)keyMapper
{
  return [[JSONKeyMapper alloc] initWithDictionary:@{ @"post_date": @"post_date", @"title": @"title", @"author": @"author", @"summary": @"summary", @"body": @"body", @"footer": @"footer", @"status": @"status" }];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName
{
  NSArray *optionalProperties = @[@"post_date", @"title", @"author", @"summary", @"body", @"footer", @"status"];

  if ([optionalProperties containsObject:propertyName]) {
    return YES;
  }
  else {
    return NO;
  }
}

@end
