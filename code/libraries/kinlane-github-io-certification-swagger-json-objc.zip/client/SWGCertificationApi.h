#import <Foundation/Foundation.h>
#import "SWGCertification.h"
#import "SWGObject.h"


@interface SWGCertificationApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGCertificationApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 all certifications
 all certifications

 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 @param query a text query to search across certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) getCertificationsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 add a certification post
 add a certification post

 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 @param post_date date the certification was posted
 @param title ttle for the certification
 @param author author of the certification
 @param summary summary for the certification
 @param body full text for the certification
 @param footer curated id the certification originated from
 @param status status of the certification
 @param curated_id full text for the certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) addCertificationWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     post_date:(NSString*) post_date 
     title:(NSString*) title 
     author:(NSString*) author 
     summary:(NSString*) summary 
     body:(NSString*) body 
     footer:(NSString*) footer 
     status:(NSString*) status 
     curated_id:(NSString*) curated_id 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 published certifications
 published certifications

 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) getPublishedCertificationsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 Retrieve a certification using its slug
 Returns the certification detail

 @param certification_id the unique id for certification entry
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) getCertificationWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 update certification
 update certification

 @param certification_id the unique id for certification entry
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 @param post_date date the certification was posted
 @param title ttle for the certification
 @param author author of the certification
 @param summary summary for the certification
 @param body full text for the certification
 @param footer curated id the certification originated from
 @param status status of the certification
 @param curated_id full text for the certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) updateCertificationWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     post_date:(NSString*) post_date 
     title:(NSString*) title 
     author:(NSString*) author 
     summary:(NSString*) summary 
     body:(NSString*) body 
     footer:(NSString*) footer 
     status:(NSString*) status 
     curated_id:(NSString*) curated_id 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 delete certification
 delete certification

 @param certification_id the unique id for certification entry
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) deleteCertificationWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    



@end