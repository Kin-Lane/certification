#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGCertification
@end
  
@interface SWGCertification : SWGObject

/* date the certification was posted [optional]
 */
@property(nonatomic) NSString* post_date;
/* title for the certification [optional]
 */
@property(nonatomic) NSString* title;
/* author of the certification [optional]
 */
@property(nonatomic) NSString* author;
/* summary for the certification [optional]
 */
@property(nonatomic) NSString* summary;
/* full body text of the certification [optional]
 */
@property(nonatomic) NSString* body;
/* footer text for the certification [optional]
 */
@property(nonatomic) NSString* footer;
/* status of the certification [optional]
 */
@property(nonatomic) NSString* status;

@end
