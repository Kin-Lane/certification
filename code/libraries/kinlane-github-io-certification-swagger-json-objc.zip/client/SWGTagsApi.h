#import <Foundation/Foundation.h>
#import "SWGCertification.h"
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 certification tags by week certifications
 certification tags by week certifications

 @param tag the tag to filter by
 @param week the week to filter by, defaults to this week
 

 return type: NSArray<SWGCertification>*
 */
-(NSNumber*) getCertificationTagCCertificationWithCompletionBlock :(NSString*) tag 
     week:(NSString*) week 
    
    completionHandler: (void (^)(NSArray<SWGCertification>* output, NSError* error))completionBlock;
    


/**

 certification tags
 certification tags

 @param certification_id id for certification
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getcertificationTagsWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add tag to certification
 add tag to certification

 @param certification_id id for the certification
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addCertificationTagWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete certification tag
 delete certification tag

 @param certification_id id for the certification
 @param appid your appid for accessing the certification
 @param appkey your appkey for accessing the certification
 @param tag tag to remove from certification
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deletecertificationTagWithCompletionBlock :(NSString*) certification_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end