package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Certification;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.util.Map;
import java.util.HashMap;
import java.io.File;

public class CertificationApi {
  String basePath = "https://certification.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  
  public List<Certification>  getCertifications (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Certification>  addCertification (String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Certification>  getPublishedCertifications (String appid, String appkey) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/published/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Certification>  getCertification (String certificationId, String appid, String appkey) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json").replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Certification>  updateCertification (String certificationId, String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json").replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  
  public List<Certification>  deleteCertification (String certificationId, String appid, String appkey) throws ApiException {
    Object postBody = null;

    

    // create path and map variables
    String path = "/certification/{certification_id}/".replaceAll("\\{format\\}","json").replaceAll("\\{" + "certificationId" + "\\}", apiInvoker.escapeString(certificationId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    // header params
    Map<String, String> headerParams = new HashMap<String, String>();
    // form params
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    

    

    String[] contentTypes = {
      
    };
    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if (contentType.startsWith("multipart/form-data")) {
      // file uploading
      MultipartEntityBuilder builder = MultipartEntityBuilder.create();
      

      HttpEntity httpEntity = builder.build();
      postBody = httpEntity;
    } else {
      // normal form params
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Certification>) ApiInvoker.deserialize(response, "array", Certification.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
