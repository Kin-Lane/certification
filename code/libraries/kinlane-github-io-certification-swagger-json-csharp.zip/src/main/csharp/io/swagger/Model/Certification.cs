using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Certification {
    

    /* date the certification was posted */
    
    public string PostDate { get; set; }

    

    /* title for the certification */
    
    public string Title { get; set; }

    

    /* author of the certification */
    
    public string Author { get; set; }

    

    /* summary for the certification */
    
    public string Summary { get; set; }

    

    /* full body text of the certification */
    
    public string Body { get; set; }

    

    /* footer text for the certification */
    
    public string Footer { get; set; }

    

    /* status of the certification */
    
    public string Status { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Certification {\n");
      
      sb.Append("  PostDate: ").Append(PostDate).Append("\n");
      
      sb.Append("  Title: ").Append(Title).Append("\n");
      
      sb.Append("  Author: ").Append(Author).Append("\n");
      
      sb.Append("  Summary: ").Append(Summary).Append("\n");
      
      sb.Append("  Body: ").Append(Body).Append("\n");
      
      sb.Append("  Footer: ").Append(Footer).Append("\n");
      
      sb.Append("  Status: ").Append(Status).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}