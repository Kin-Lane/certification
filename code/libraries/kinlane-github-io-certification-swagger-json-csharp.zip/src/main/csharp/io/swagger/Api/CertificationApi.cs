using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class CertificationApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public CertificationApi(String basePath = "https://certification.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// all certifications all certifications
    /// </summary>
    /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
     /// <param name="Query">a text query to search across certification</param>
    
    /// <returns></returns>
    public List<certification>  GetCertifications (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/certification/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add a certification post add a certification post
    /// </summary>
    /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
     /// <param name="PostDate">date the certification was posted</param>
     /// <param name="Title">ttle for the certification</param>
     /// <param name="Author">author of the certification</param>
     /// <param name="Summary">summary for the certification</param>
     /// <param name="Body">full text for the certification</param>
     /// <param name="Footer">curated id the certification originated from</param>
     /// <param name="Status">status of the certification</param>
     /// <param name="CuratedId">full text for the certification</param>
    
    /// <returns></returns>
    public List<certification>  AddCertification (string Appid, string Appkey, string PostDate, string Title, string Author, string Summary, string Body, string Footer, string Status, string CuratedId) {
      // create path and map variables
      var path = "/certification/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (PostDate != null){
        queryParams.Add("post_date", apiInvoker.ParameterToString(PostDate));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Summary != null){
        queryParams.Add("summary", apiInvoker.ParameterToString(Summary));
      }
      if (Body != null){
        queryParams.Add("body", apiInvoker.ParameterToString(Body));
      }
      if (Footer != null){
        queryParams.Add("footer", apiInvoker.ParameterToString(Footer));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (CuratedId != null){
        queryParams.Add("curated_id", apiInvoker.ParameterToString(CuratedId));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// published certifications published certifications
    /// </summary>
    /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
    
    /// <returns></returns>
    public List<certification>  GetPublishedCertifications (string Appid, string Appkey) {
      // create path and map variables
      var path = "/certification/published/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// Retrieve a certification using its slug Returns the certification detail
    /// </summary>
    /// <param name="CertificationId">the unique id for certification entry</param>
     /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
    
    /// <returns></returns>
    public List<certification>  GetCertification (string CertificationId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/certification/{certification_id}/".Replace("{format}","json").Replace("{" + "certification_id" + "}", apiInvoker.ParameterToString(CertificationId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// update certification update certification
    /// </summary>
    /// <param name="CertificationId">the unique id for certification entry</param>
     /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
     /// <param name="PostDate">date the certification was posted</param>
     /// <param name="Title">ttle for the certification</param>
     /// <param name="Author">author of the certification</param>
     /// <param name="Summary">summary for the certification</param>
     /// <param name="Body">full text for the certification</param>
     /// <param name="Footer">curated id the certification originated from</param>
     /// <param name="Status">status of the certification</param>
     /// <param name="CuratedId">full text for the certification</param>
    
    /// <returns></returns>
    public List<certification>  UpdateCertification (string CertificationId, string Appid, string Appkey, string PostDate, string Title, string Author, string Summary, string Body, string Footer, string Status, string CuratedId) {
      // create path and map variables
      var path = "/certification/{certification_id}/".Replace("{format}","json").Replace("{" + "certification_id" + "}", apiInvoker.ParameterToString(CertificationId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (PostDate != null){
        queryParams.Add("post_date", apiInvoker.ParameterToString(PostDate));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Summary != null){
        queryParams.Add("summary", apiInvoker.ParameterToString(Summary));
      }
      if (Body != null){
        queryParams.Add("body", apiInvoker.ParameterToString(Body));
      }
      if (Footer != null){
        queryParams.Add("footer", apiInvoker.ParameterToString(Footer));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (CuratedId != null){
        queryParams.Add("curated_id", apiInvoker.ParameterToString(CuratedId));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete certification delete certification
    /// </summary>
    /// <param name="CertificationId">the unique id for certification entry</param>
     /// <param name="Appid">your appid for accessing the certification</param>
     /// <param name="Appkey">your appkey for accessing the certification</param>
    
    /// <returns></returns>
    public List<certification>  DeleteCertification (string CertificationId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/certification/{certification_id}/".Replace("{format}","json").Replace("{" + "certification_id" + "}", apiInvoker.ParameterToString(CertificationId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<certification>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<certification>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<certification>) ApiInvoker.deserialize(response, typeof(List<certification>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
